This is the library folder. Feel free to add any file here.
The system is pretty simple. Each file will have its own freecode bank.
All labels created with this system will appear on all relevant level/game mode/overworld
codes.
You can also add whatever non-asm file you want. They will be included as binary file and
their name will be the label used.